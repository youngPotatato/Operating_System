import java.util.ArrayList;
import java.util.Scanner;

public class MemoryManager {
    //printing info switch
    private static final boolean DEBUG_MODE = true;
    //first memory node in dll
    private Node head;
    //store item id in memory
    private ArrayList<Integer> idList;
    private class Node{
        private int st;
        private int end;
        private int id;
        private int nodeIndex;
        //status true-- node free
        //       false--node occupied
        private boolean status;
        private Node previous;
        private Node next;
        public Node(int size, int st, int id, boolean stat, int nodeIndex, Node p, Node n){
            this.st = st;
            end = st + size - 1;
            status = stat;
            this.nodeIndex = nodeIndex;
            if(!stat) this.id = id;
            if(p != null) previous = p;
            if(n != null) next = n;
        }
    }
    public MemoryManager(int size){
        head = new Node(size,1,0,true,1,null,null);
        idList = new ArrayList<>();
    }
    private boolean fadd(int id, int size){
        return fadd(id, size, head);
    }
    //add new node in hole
    private void addNewNode(Node n, int id, int size){
        Node newN = new Node(n.end - n.st + 1 - size, n.st + size, -1, true, n.nodeIndex + 1, n, n.next);
        if(newN.next != null) {
            newN.next.previous = newN;
            resetIndex(newN.next, newN.next.nodeIndex + 1);
        }
        n.end = n.st + size -1;
        n.next = newN;
        n.status = false;
        n.id = id;
    }
    private boolean fadd(int id, int size, Node n){
        if(n == null) return false;
        int comp = Integer.compare(n.end - n.st + 1, size);
        if(!n.status || comp<0 ) return fadd(id,size,n.next);
        if(comp == 0) {n.status = false; n.id = id;}
        if(comp > 0){
            addNewNode(n,id,size);
        }
        if(DEBUG_MODE) System.out.println("First fit add Item " + id + " size " + size);
        return true;
    }

    /**
     *
     * all the runTimeException are used for error debug
     * no one should be thrown
     */
    private void resetIndex(Node n, int index){
        if(n == null) throw new RuntimeException("wrong status 4");
        n.nodeIndex = index;
        if(n.next != null)
            resetIndex(n.next,index+1);
    }

    /**
     * used for coalescing adjacent holes
     * n1's nodeIndex is smaller than n2
     * all the runTimeException are used for error debug
     * no one should be thrown
     * coalesce adjacent holes
     */
    private Node coalesce(Node n1, Node n2){
        if(n2.nodeIndex <= n1.nodeIndex) throw new RuntimeException("wrong status 1");
        if(!n2.status) throw new RuntimeException("wrong status 2");
        if(!n1.status) throw new RuntimeException("wrong status 3");
        Node n = new Node(n2.end - n1.st + 1,n1.st,0,true,n1.nodeIndex, n1.previous,n2.next);
        if(n2.next != null){
            resetIndex(n2.next,n1.nodeIndex+1);
            n2.next.previous = n;
        }
        if(n1.previous != null) {
            n1.previous.next = n;
        }
        return n;
    }

    private void freeCorrect(int id){
        if(id < 0){
            System.out.println("invalid command");
            return;
        }
        if(!idList.contains(id)){
            System.out.println("item not in memory, free failed");
            return;
        }
        head = freeNode(id,head);
    }

    /**
     *
     * recursive helper function for free op
     */
    private Node freeNode(int id, Node n){
        if(n==null) return null;
        if(n.id == id) {    // id matching, udpate id and status
            n.id = -1;
            n.status = true;
        }else {             // not matching, recursive call
            n.next = freeNode(id, n.next);
        }
        // if possible, coalesce
        if (n.status && n.next != null && n.next.status) {
            Node nex = n.next;
            while (nex.next != null && nex.next.status)
                nex = nex.next;
            n = coalesce(n, nex);
        }
        //remove id in list
        if(n.nodeIndex == 1) {
            idList.remove((Object)id);
            if (DEBUG_MODE)
                System.out.println("FREE Item " + id);
        }
        return n;
    }

    /**
     *
     * @param condition
     *      true: best fit
     *      false: worst fit
     *  runTimeException is used for error debug
     *  should not be thrown
     */
    private boolean bwadd(int id, int size, boolean condition){
        if(size <= 0) throw new IllegalArgumentException("size is illegal");
        //find matching node
        Node n = condition? BestFitNode(size):WorstFitNode(size);
        if(n == null) return false;
        int comp = Integer.compare(n.end - n.st + 1, size);
        // if sizes are equal
        // update and done
        // if not
        // creating new node in the hole
        if(comp == 0){
            n.status = false;
            n.id = id;
        }else if( comp > 0) {
            addNewNode(n,id,size);
        }else{
            throw new RuntimeException("Best/Worst fit add error!");
        }
        if(DEBUG_MODE)
            if(condition)
                System.out.println("Best fit add Item " + id + " size " + size);
            else
                System.out.println("Worst fit add Item " + id + " size " + size);
        return true;
    }
    //return null when no fit found
    // when mutiple choices available,
    //choose the node closest from head node
    private Node BestFitNode(int size){
        int bestSize = Integer.MAX_VALUE;
        Node result = null;
        Node n = head;
        while(n != null){
            if(!n.status){
                n = n.next;
                continue;
            }
            int s = n.end - n.st + 1;
            if(s == size) return n;
            if(s > size){
                if(s < bestSize){
                    result = n;
                    bestSize = s;
                }
            }
            n = n.next;
        }
        return result;
    }
    //return null when no fit found
    // when mutiple choices available,
    //choose the node most far away from head node
    private Node WorstFitNode(int size){
        int worstSize = 0;
        Node result = null;
        Node n = head;
        while(n != null){
            if(!n.status){
                n = n.next;
                continue;
            }
            int s = n.end - n.st + 1;
            if(s >= size){
                if(s >= worstSize){
                    result = n;
                    worstSize = s;
                }
            }
            n = n.next;
        }
        return result;
    }

    /**
     * display function
     * RuntimeException is used for error checking
     * should not be thrown
     */
    public void display(){
        System.out.println("Bytes:");
        Node n = head;
        while(n != null){
            String status = n.status?"Free":String.format("Item %d",n.id);
            String range = (n.st == n.end)?String.format("%d  ",n.st):String.format("%d-%d",n.st,n.end);
            System.out.println(range+"     "+status);
            if(n.next != null && n.next.nodeIndex - n.nodeIndex != 1)
                throw new RuntimeException("nodeIndex not match");
            if(n.previous != null && n.nodeIndex - n.previous.nodeIndex != 1)
                throw new RuntimeException("nodeIndex not match");
            n=n.next;
        }
        System.out.println("__________________________________");
    }
    private boolean add(int id, int size,String pat){
        if(idList.contains(id)) {
            System.out.println("item is already in memory");
            return false;
        }
        if(id < 0 || size <= 0) {
            System.out.println("invalid command");
            return false;
        }
        if(pat.equals("f")){
            if(fadd(id,size)){
                idList.add(id);
                return true;
            }
            return false;
        }else if(pat.equals("b")){
            if(bwadd(id,size,true)){
                idList.add(id);
                return true;
            }
            return false;
        }else if(pat.equals("w")){
            if(bwadd(id,size,false)){
                idList.add(id);
                return true;
            }
            return false;
        }else{
            throw new RuntimeException("error status 5");
        }
    }
    //command line processor
    public void cmdProcessor(Scanner s){
        while(s.hasNextLine()){
            String cmd = s.nextLine().trim();
            if(cmd.matches("a\\s+\\d+\\s+\\d+\\s+[fbw]")){
                String para[] = cmd.split("\\s+");
                if(!add(Integer.parseInt(para[1]),Integer.parseInt(para[2]),para[3]))
                    System.out.println("add fail");
            } else if(cmd.matches("f\\s+\\d+")) {
                String para[] = cmd.split("\\s+");
                freeCorrect(Integer.parseInt(para[1]));
            } else if(cmd.matches("d")) {
                this.display();
            } else if(cmd.matches("q")) {
                System.out.println("quit command");
                return;
            }else {
                //error, but not terminate
                System.out.println("invalid command");
            }
        }
    }
    public static void main(String [] args){
        Scanner rder = new Scanner(System.in);
        int argu = Integer.valueOf(args[0]);
        if(argu <= 0) {
            System.err.println("invalid argument");
            return;
        }
        MemoryManager mm = new MemoryManager(argu);
        mm.cmdProcessor(rder);
    }

}
