import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;

public class VirtualMemory {
    private int f;
    private int x;
    //reference string
    private StringBuilder myReferenceString;
    private final static int NUM_ACCESS = 20000;
    private final static int NUM_ITERATIONS = 30;
    private Queue<Character> vMemFIFO;
    private Queue<Character> vMemFIFO1;
    private Queue<Character> vMemFIFO2;
    private LinkedList<Character> vMemLRU;
    //index 0 f size fifo faults number
    //index 1 f + 1 size fifo faults number
    //index 2 f + 2 size fifo faults number
    private int[] minFaults;
    private int[] maxFaults;
    private int[] aveFaults;
    //belady[0] f+1 belady number
    //belady[1] f+2 belady number
    private int[] belady = new int[2];
    public VirtualMemory(int f, int x){
        this.f = f;
        this.x = x;
        //virtual memory frames
        vMemFIFO = new ArrayBlockingQueue<>(f);
        vMemFIFO1 = new ArrayBlockingQueue<>(f+1);
        vMemFIFO2 = new ArrayBlockingQueue<>(f+2);
        vMemLRU = new LinkedList<>();
        myReferenceString = new StringBuilder();
        minFaults = new int[4];
        maxFaults = new int[4];
        aveFaults = new int[4];
        for(int i = 0; i < 4; i ++){
            minFaults[i] = Integer.MAX_VALUE;
            maxFaults[i] = Integer.MIN_VALUE;
        }
    }
    private StringBuilder refStringGen(int x){
        StringBuilder result = new StringBuilder();
        //generate random value and build ref string
        Random myRGen = new Random();
        for(int i = 0; i < NUM_ACCESS; i ++){
            result.append((char)(myRGen.nextInt(x) + 1));
        }
        return result;
    }
    //run one iteration of 3 fifo algorithms
    private void fifoRunOneRound(int index, int[] faultNum, StringBuilder sB, Queue<Character> vMem, int f){
        for(int i = 0; i < NUM_ACCESS; i ++){
            if (vMem.contains(sB.charAt(i)))
                continue;
            if(vMem.size() >= f) {
                vMem.poll();
            }
            faultNum[index]++;
            vMem.offer(sB.charAt(i));
        }
        if(minFaults[index] > faultNum[index])
            minFaults[index] = faultNum[index];
        if(maxFaults[index] < faultNum[index])
            maxFaults[index] = faultNum[index];
        aveFaults[index] += faultNum[index];
    }
    // use 2-d matrix to calcute lru cnt
    private int lruIndex(int[][] diagonalIndex){
        int index = 0;
        int minCnt = Integer.MAX_VALUE;
        for(int i = 0; i <f; i ++){
            int tempCnt = 0;
            for(int j = 0; j < f; j ++){
                tempCnt += diagonalIndex[i][j];
            }
            if(tempCnt < minCnt){
                index = i;
                minCnt = tempCnt;
            }
        }
        return index;
    }
    //update 2-d matrix for lru
    private void updateLruMatrix(int[][] diagonalIndex,int index){
        for(int j = 0; j < f; j ++){
            diagonalIndex[index][j] = 1;
        }
        for(int k = 0; k < f; k ++){
            diagonalIndex[k][index] = 0;
        }
    }
    // run one iteration of lru
    // update fault number
    private void lruRunOneRound(int[][] diagonalIndex, int[] faultNum, StringBuilder sB, LinkedList<Character> vMem, int f) {
        for(int i = 0; i < NUM_ACCESS; i ++){
            int ii = vMem.indexOf(sB.charAt(i));
            if (ii >-1) {
                updateLruMatrix(diagonalIndex,ii);
                continue;
            }else{
                int replaceIndex = lruIndex(diagonalIndex);
                if(vMem.size() >= f){
                    vMem.remove(replaceIndex);
                }
                faultNum[3]++;
                vMem.add(replaceIndex,sB.charAt(i));
                updateLruMatrix(diagonalIndex,replaceIndex);
            }
        }
        if(minFaults[3] > faultNum[3])
            minFaults[3] = faultNum[3];
        if(maxFaults[3] < faultNum[3])
            maxFaults[3] = faultNum[3];
        aveFaults[3] += faultNum[3];
    }
    public void runOneRound(){
        int[] faultNum = new int[4];
        myReferenceString = refStringGen(x);

        //myReferenceString.append(new char[]{'7','0','1','2','0','3','0','4','2','3','0','3','2','1','2','0','1','7','0','1'});
        //myReferenceString.append(new char[]{'1','2','3','4','1','2','5','1','2','3','4','5'});
        int[][] diagonalIndex = new int[f][f];
        fifoRunOneRound(0,faultNum,myReferenceString,vMemFIFO,f);
        fifoRunOneRound(1,faultNum,myReferenceString,vMemFIFO1,f+1);
        fifoRunOneRound(2,faultNum,myReferenceString,vMemFIFO2,f+2);
        //belady
        if(faultNum[1]> faultNum[0])
            belady[0]++;
        if(faultNum[2]> faultNum[0])
            belady[1]++;
        //LRU f
        lruRunOneRound(diagonalIndex,faultNum,myReferenceString,vMemLRU,f);
    }
    //log as instructions
    private void log(){
        System.out.println(f + " frames,    " + NUM_ACCESS + " of accesses," + NUM_ITERATIONS + " of iterations");
        System.out.println("FIFO f    :         Average faults " + (float)(aveFaults[0]/NUM_ITERATIONS) + " Min faults "
                + minFaults[0] + " Max faults " + maxFaults[0]);
        System.out.println("FIFO f + 1:         Average faults " + (float)(aveFaults[1]/NUM_ITERATIONS) + " Min faults "
                + minFaults[1] + " Max faults " + maxFaults[1] + "   " + belady[0] + " of Belady    " + (float)(belady[0]*100/NUM_ITERATIONS) + "% of Belady");
        System.out.println("FIFO f + 2:         Average faults " + (float)(aveFaults[2]/NUM_ITERATIONS) + " Min faults "
                + minFaults[2] + " Max faults " + maxFaults[2] + "   " + belady[1] + " of Belady    " + (float)(belady[1]*100/NUM_ITERATIONS) + "% of Belady");
        System.out.println("LRU       :         Average faults " + (float)(aveFaults[3]/NUM_ITERATIONS) + " Min faults "
                        + minFaults[3] + " Max faults " + maxFaults[3]);
    }
    public static void main(String[] args){
        if(Integer.parseInt(args[0])<=0 || Integer.parseInt(args[1])<= 0) {
            System.err.println("invalid augments");
            return;
        }
        VirtualMemory myVM = new VirtualMemory(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
        int i = myVM.NUM_ITERATIONS;
        while(i-- > 0)
            myVM.runOneRound();
        myVM.log();
    }
}
