//
// Created by yy on 1/22/18.
//

#ifndef PROGRAM1_TEST_POINT_H
#define PROGRAM1_TEST_POINT_H
typedef struct point{
    float x;
    float y;
} point;
#endif //PROGRAM1_TEST_POINT_H
